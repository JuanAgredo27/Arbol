package arbolhuffman;

import javax.swing.JOptionPane;

/**
 *
 * @author hvarg
 */
public class ArbolHuffman {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
    }
    
}
