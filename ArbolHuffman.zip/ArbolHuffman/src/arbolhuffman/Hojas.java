/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arbolhuffman;


class Hojas extends Arbol{
    
    public final char val;
    
    public Hojas(int rep,char valor){
        super(rep);
        val = valor;
    }   
}
