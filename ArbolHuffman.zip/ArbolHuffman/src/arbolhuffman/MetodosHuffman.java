
package arbolhuffman;

import java.util.PriorityQueue;
import javax.swing.JOptionPane;

public class MetodosHuffman {
    public static Arbol CrearArbol(int [] rep){
        PriorityQueue<Arbol> arboles = new PriorityQueue<Arbol>();
        
        for(int i =0;i < rep.length;i++){
            if(rep[i] > 0)
                arboles.offer(new Hojas(rep[i], (char)i));
        }
          while(arboles.size() > 1){
                Arbol a = arboles.poll();
                Arbol b = arboles.poll();
                arboles.offer(new Nodo(a,b));   
            }
        
       return arboles.poll();
    }
    
  public static String Codificar(Arbol arbol,String codificar){
      assert arbol != null;
      
      String Codificartxt = "";
      for(char c: codificar.toCharArray()){
          Codificartxt += (getCodigo(arbol, new StringBuffer(), c));
      }
      
      return Codificartxt;
  }  
    
  public static String getCodigo(Arbol arbol, StringBuffer pref, char w){
      assert arbol != null;
      
      if(arbol instanceof Hojas){
          Hojas hoja = (Hojas)arbol;
          
            if(hoja.val == w){
                return pref.toString();
            } 
      }else if(arbol instanceof Nodo){
          Nodo nodo = (Nodo)arbol;
          
          pref.append('0');
          String izq = getCodigo(nodo.izq , pref, w);
          pref.deleteCharAt(pref.length()-1);
          
          
          pref.append('1');
          String der = getCodigo(nodo.der, pref, w);
          pref.deleteCharAt(pref.length() -1);
          
          if(izq == null) return der; else return izq;
      }
    return null;
  }
  
  public static void imprimir(Arbol arbol , StringBuffer pref){
      assert arbol != null;
      if(arbol instanceof Hojas){
          Hojas hoja = (Hojas)arbol;
          
          System.out.println(hoja.val + "\t" + hoja.repetir + "\t\t" + pref);
          JOptionPane.showMessageDialog(null, "Caracter Repetido\n" + hoja.val + "  "
                  + "      "
                  + "      "
                  + "      "
                  + "      "  );
          
      }else if(arbol instanceof Nodo){
          Nodo nodo = (Nodo)arbol;
          
          pref.append('0');
          imprimir(nodo.izq, pref);
          pref.deleteCharAt(pref.length()-1);
          
          
          pref.append('1');
          imprimir(nodo.der, pref);
          pref.deleteCharAt(pref.length()-1);
      }
   }
  
    public static String Decodificar(Arbol arbol, String codificar) {
        assert arbol != null;

        String decodificartxt = "";
        Nodo nodo = (Nodo) arbol;
        for (char code : codificar.toCharArray()) {
            if (code == '0') {
                if (nodo.izq instanceof Hojas) {
                    decodificartxt += ((Hojas) nodo.izq).val;
                    nodo = (Nodo) arbol;
                } else {
                    nodo = (Nodo) nodo.izq;
                }
            } else if (code == '1') {
                if (nodo.der instanceof Hojas) {
                    decodificartxt += ((Hojas) nodo.der).val;
                    nodo = (Nodo) arbol;
                } else {
                    nodo = (Nodo) nodo.der;
                }
            }

        }
        return decodificartxt;
    }
 }

